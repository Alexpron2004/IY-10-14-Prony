package mp

import "fmt"

type Map struct {
	it iterator
	mp map[int64]int64
}

func NewMap() *Map {
	mp := &Map{
		mp: make(map[int64]int64)
		it: iterator
	}
	return
}

func (s Map) Add(data int64) (id int64) {
	id = m.it.get
}

func (s Map) Get(data int64) (id int64, ok bool) {
	data, ok = m.mp[id]
}

func (s Map) Del(data int64) (id int64, ok bool) {
	delete()
}
func main() {
	a := make([]int64, 0, 5)
	fmt.Println(len(a))
}
